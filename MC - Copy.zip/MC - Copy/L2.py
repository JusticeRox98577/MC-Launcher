import os
import json
import time
import sys
import subprocess
import requests

CONFIG_FILE = "config.json"
MINECRAFT_JAR = "minecraft.jar"
MINECRAFT_VERSION = "1.20.1"

# Default settings
default_config = {
    "username": "Player",
    "version": MINECRAFT_VERSION,
    "java_path": "java"
}

def load_config():
    """ Load configuration file or create a new one. """
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as file:
            return json.load(file)
    else:
        return default_config

def save_config(config):
    """ Save configuration to a file. """
    with open(CONFIG_FILE, "w") as file:
        json.dump(config, file, indent=4)

def check_java():
    """ Check if Java is installed and usable. """
    try:
        result = subprocess.run([default_config["java_path"], "-version"], capture_output=True, text=True)
        if "version" in result.stderr:
            print("✅ Java detected successfully.")
            return True
    except FileNotFoundError:
        print("❌ Error: Java is not installed or not in PATH.")
    return False

def launch_minecraft(config):
    """ Launch Minecraft with the selected version and username. """
    username = config["username"]
    java_path = config["java_path"]
    jar_path = os.path.join(os.getcwd(), MINECRAFT_JAR)

    if not check_java():
        print("⚠️ Please install Java before running Minecraft.")
        input("Press Enter to exit...")
        return

    if not os.path.exists(jar_path):
        print(f"❌ Minecraft {MINECRAFT_VERSION} JAR not found in the current directory.")
        input("Press Enter to exit...")
        return

    print(f"\n🚀 Launching Minecraft {MINECRAFT_VERSION} as {username}...\n")
    time.sleep(3)

    try:
        command = [java_path, "-jar", jar_path, "--username", username]
        subprocess.run(command)
    except Exception as e:
        print(f"❌ Error launching Minecraft: {e}")
    
    input("Press Enter to exit...")  # Prevents instant closing

if __name__ == "__main__":
    config = load_config()
    print("🎮 Welcome to Python Minecraft Launcher! 🎮")
    config["username"] = input("Enter your username: ")
    save_config(config)
    launch_minecraft(config)

import subprocess
import time
import sys

def install_dependencies():
    print("Starting dependency installation...")
    time.sleep(5)  # Wait before installation

    dependencies = ["requests"]

    for package in dependencies:
        try:
            print(f"Installing {package}...")
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", package],
                check=True,
                capture_output=True,
                text=True
            )
            print(result.stdout)
        except subprocess.CalledProcessError as e:
            print(f"Error installing {package}: {e.stderr}")
    
    print("All dependencies installed successfully.")
    time.sleep(5)  # Wait after installation

if __name__ == "__main__":
    install_dependencies()

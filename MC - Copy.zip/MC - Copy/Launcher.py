import os
import json
import time
import sys
import subprocess
import requests

CONFIG_FILE = "config.json"
MINECRAFT_DIR = os.path.expanduser("~/.minecraft")

# New working download links (MC Libraries API)
MINECRAFT_VERSIONS = {
    "1.16.5": "https://mclibs.download/version/1.16.5/client.jar",
    "1.18.2": "https://mclibs.download/version/1.18.2/client.jar",
    "1.19.4": "https://mclibs.download/version/1.19.4/client.jar",
    "1.20.1": "https://mclibs.download/version/1.20.1/client.jar"
}

# Default settings
default_config = {
    "username": "Player",
    "version": "1.20.1",
    "java_path": "java"
}

def load_config():
    """ Load configuration file or create a new one. """
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as file:
            return json.load(file)
    else:
        return default_config

def save_config(config):
    """ Save configuration to a file. """
    with open(CONFIG_FILE, "w") as file:
        json.dump(config, file, indent=4)

def select_version():
    """ Allow the user to select a Minecraft version. """
    versions = list(MINECRAFT_VERSIONS.keys())
    print("\nAvailable Minecraft Versions:")
    for i, v in enumerate(versions):
        print(f"{i + 1}. {v}")

    choice = input("Select a version (Enter number): ")
    try:
        return versions[int(choice) - 1]
    except (IndexError, ValueError):
        print("Invalid choice, using default version.")
        return default_config["version"]

def check_java():
    """ Check if Java is installed and usable. """
    try:
        result = subprocess.run([default_config["java_path"], "-version"], capture_output=True, text=True)
        if "version" in result.stderr:
            print("✅ Java detected successfully.")
            return True
    except FileNotFoundError:
        print("❌ Error: Java is not installed or not in PATH.")
    return False

def download_minecraft(version):
    """ Download the Minecraft JAR file from a working source. """
    if version not in MINECRAFT_VERSIONS:
        print(f"❌ Error: No download link found for version {version}.")
        return False

    jar_path = os.path.join(MINECRAFT_DIR, "versions", version, "minecraft.jar")
    
    if os.path.exists(jar_path):
        print(f"✅ Minecraft {version} is already downloaded.")
        return True

    print(f"⬇️ Downloading Minecraft {version}...")

    os.makedirs(os.path.dirname(jar_path), exist_ok=True)
    download_url = MINECRAFT_VERSIONS[version]

    try:
        headers = {
            "User-Agent": "Minecraft-Launcher"
        }
        response = requests.get(download_url, stream=True, headers=headers, verify=False)  # SSL DISABLED
        response.raise_for_status()
        
        with open(jar_path, "wb") as file:
            for chunk in response.iter_content(chunk_size=1024):
                file.write(chunk)

        print(f"✅ Minecraft {version} downloaded successfully!")
        return True

    except requests.exceptions.RequestException as e:
        print(f"❌ Download failed: {e}")
        return False

def launch_minecraft(config):
    """ Launch Minecraft with the selected version and username. """
    minecraft_dir = MINECRAFT_DIR
    version = config["version"]
    username = config["username"]
    java_path = config["java_path"]

    if not check_java():
        print("⚠️ Please install Java before running Minecraft.")
        input("Press Enter to exit...")
        return

    jar_path = os.path.join(minecraft_dir, "versions", version, "minecraft.jar")

    if not os.path.exists(jar_path):
        print(f"❌ Error: Minecraft version {version} is not installed.")
        if not download_minecraft(version):
            input("Press Enter to exit...")
            return

    print(f"\n🚀 Launching Minecraft {version} as {username}...\n")
    time.sleep(3)

    try:
        command = [java_path, "-jar", jar_path, "--username", username]
        subprocess.run(command)
    except Exception as e:
        print(f"❌ Error launching Minecraft: {e}")
    
    input("Press Enter to exit...")  # Prevents instant closing

if __name__ == "__main__":
    config = load_config()

    print("🎮 Welcome to Python Minecraft Launcher! 🎮")
    config["username"] = input("Enter your username: ")
    config["version"] = select_version()

    save_config(config)
    launch_minecraft(config)
